# WebPilot Android

Android controller for authorized website testing.

Features:
- 1 to 20 concurrent-session controls
- Target URL
- Configurable interval
- Start / Stop All
- Live session grid
- Material 3 UI
- GitHub Actions APK build

See `GITHUB_BUILD_GUIDE.md` for APK build instructions.
