import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const WebPilotApp());

class WebPilotApp extends StatelessWidget {
  const WebPilotApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'WebPilot',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo), useMaterial3: true),
    home: const DashboardPage(),
  );
}

enum SessionStatus { idle, running, completed, failed, stopped }

class SessionState {
  SessionState(this.id);
  final int id;
  SessionStatus status = SessionStatus.idle;
  String url = '';
  int loadMs = 0;
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final urlController = TextEditingController(text: 'https://example.com');
  final intervalController = TextEditingController(text: '5');
  int concurrency = 20, durationMinutes = 5, cycle = 0;
  bool running = false;
  Timer? timer;
  final sessions = List.generate(20, (i) => SessionState(i + 1));

  @override
  void dispose() { timer?.cancel(); urlController.dispose(); intervalController.dispose(); super.dispose(); }

  void startTest() {
    final url = urlController.text.trim();
    final parsed = Uri.tryParse(url);
    if (parsed == null || (parsed.scheme != 'https' && parsed.scheme != 'http') || parsed.host.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('یک URL معتبر وارد کنید.')));
      return;
    }
    setState(() {
      running = true; cycle = 0;
      for (final s in sessions) {
        s.status = s.id <= concurrency ? SessionStatus.running : SessionStatus.idle;
        s.url = s.id <= concurrency ? url : '';
      }
    });
    final seconds = (int.tryParse(intervalController.text) ?? 5).clamp(1, 3600);
    timer?.cancel();
    timer = Timer.periodic(Duration(seconds: seconds), (_) {
      if (!mounted || !running) return;
      setState(() {
        cycle++;
        for (final s in sessions.take(concurrency)) {
          s.loadMs = 300 + ((s.id * 137 + cycle * 83) % 1200);
        }
      });
    });
  }

  void stopTest() {
    timer?.cancel();
    setState(() {
      running = false;
      for (final s in sessions.take(concurrency)) s.status = SessionStatus.stopped;
    });
  }

  @override
  Widget build(BuildContext context) {
    final active = sessions.where((s) => s.status == SessionStatus.running).length;
    return Scaffold(
      appBar: AppBar(title: const Text('WebPilot'), actions: [
        IconButton(onPressed: () => showDialog(context: context, builder: (_) => const AlertDialog(
          title: Text('WebPilot'),
          content: Text('کنترل‌پنل اندروید برای تست مجاز سایت‌ها. اجرای واقعی مرورگرها از طریق Backend/Playwright انجام می‌شود.'),
        )), icon: const Icon(Icons.settings))
      ]),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
        Text('Authorized Website Test', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 6),
        const Text('کنترل اجرای سشن‌های مرورگر برای تست سایت‌های مجاز'),
        const SizedBox(height: 18),
        TextField(controller: urlController, keyboardType: TextInputType.url,
          decoration: const InputDecoration(labelText: 'Target URL', border: OutlineInputBorder(), prefixIcon: Icon(Icons.language))),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
          Row(children: [const Expanded(child: Text('Concurrent sessions')), Text('$concurrency')]),
          Slider(min: 1, max: 20, divisions: 19, value: concurrency.toDouble(),
            onChanged: running ? null : (v) => setState(() => concurrency = v.round())),
          Row(children: [
            const Expanded(child: Text('Interval (seconds)')),
            SizedBox(width: 90, child: TextField(controller: intervalController, keyboardType: TextInputType.number,
              decoration: const InputDecoration(border: OutlineInputBorder(), isDense: true)))
          ]),
          const SizedBox(height: 12),
          Row(children: [
            const Expanded(child: Text('Duration')),
            DropdownButton<int>(value: durationMinutes, items: const [1,5,10,30,60]
              .map((m) => DropdownMenuItem(value: m, child: Text('$m min'))).toList(),
              onChanged: running ? null : (v) => setState(() => durationMinutes = v!))
          ])
        ]))),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: running ? null : startTest, icon: const Icon(Icons.play_arrow), label: const Text('START'))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton.tonalIcon(onPressed: running ? stopTest : null, icon: const Icon(Icons.stop), label: const Text('STOP ALL')))
        ]),
        const SizedBox(height: 18),
        Row(children: [
          Expanded(child: _stat('Active', '$active')), Expanded(child: _stat('Sessions', '$concurrency')), Expanded(child: _stat('Cycle', '$cycle'))
        ]),
        const SizedBox(height: 18),
        Text('Live Sessions', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 10),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: 20,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.25),
          itemBuilder: (_, i) => _sessionCard(sessions[i])),
        const SizedBox(height: 20),
        const Card(child: Padding(padding: EdgeInsets.all(14), child: Text(
          'این نسخه رابط کنترل اندروید است. برای اجرای واقعی Playwright باید به Backend مجاز متصل شود. '
          'از آن برای جعل بازدید، تبلیغات یا دور زدن محدودیت‌های سایت‌ها استفاده نکنید.')))
      ]))
    );
  }

  Widget _stat(String title, String value) => Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 12),
    child: Column(children: [Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text(title)])));

  Widget _sessionCard(SessionState s) {
    final color = switch (s.status) {
      SessionStatus.running => Colors.green, SessionStatus.failed => Colors.red,
      SessionStatus.completed => Colors.blue, SessionStatus.stopped => Colors.orange, SessionStatus.idle => Colors.grey
    };
    final label = switch (s.status) {
      SessionStatus.running => 'RUNNING', SessionStatus.failed => 'FAILED',
      SessionStatus.completed => 'DONE', SessionStatus.stopped => 'STOPPED', SessionStatus.idle => 'IDLE'
    };
    return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [CircleAvatar(radius: 15, child: Text('${s.id}')), const SizedBox(width: 8),
        Expanded(child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.bold)))]),
      const Spacer(),
      Text(s.url.isEmpty ? 'No target' : s.url, maxLines: 1, overflow: TextOverflow.ellipsis),
      const SizedBox(height: 4),
      Text(s.loadMs == 0 ? 'Load: —' : 'Load: ${s.loadMs} ms')
    ])));
  }
}
