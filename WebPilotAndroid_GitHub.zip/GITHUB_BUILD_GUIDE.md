# ساخت APK با GitHub Actions

## 1. ساخت Repository
یک Repository جدید در GitHub بساز، مثلاً `WebPilotAndroid`.

## 2. آپلود پروژه
تمام محتویات این پوشه را داخل Repository آپلود کن و روی branch `main` قرار بده.

## 3. اجرای Build
در GitHub:
Actions → Build WebPilot Android APK → Run workflow

یا با Push روی `main`، Workflow به صورت خودکار اجرا می‌شود.

## 4. گرفتن APK
بعد از سبز شدن Workflow:
Actions → آخرین اجرای Build → بخش Artifacts → `WebPilot-Android`

فایل ZIP مربوط به artifact را دانلود کن و داخل آن `WebPilot.apk` قرار دارد.

## 5. نصب روی گوشی
فایل `WebPilot.apk` را به گوشی منتقل کن و بازش کن.
اگر Android اجازه نصب از این منبع را خواست، برای برنامه‌ای که فایل را با آن باز کرده‌ای اجازه نصب بده.

## نکته
این نسخه فعلاً پنل کنترل اندروید است. کارت‌های Session در این نسخه وضعیت رابط کاربری را نمایش می‌دهند و اجرای واقعی مرورگرهای Playwright باید به Backend مجاز متصل شود.
